"""Paquete de funciones reutilizables."""
